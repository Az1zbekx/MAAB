satr = input("Satr: ")
print(satr.replace(" ", ""))
