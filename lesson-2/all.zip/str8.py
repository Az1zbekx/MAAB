satr = input("Satr: ")
if satr:
    print("Birinchi:", satr[0])
    print("Oxirgi:", satr[-1])
