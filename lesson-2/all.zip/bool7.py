a = float(input("1-son: "))
b = float(input("2-son: "))
c = int(input("Oraliqni tekshirish uchun son: "))

if a + b > 50.8:
    print("Yig‘indi 50.8 dan katta.")
else:
    print("Yig‘indi kichik yoki teng.")

if 10 <= c <= 20:
    print("Son 10 dan 20 oralig‘ida.")
else:
    print("Son oraliqda emas.")
