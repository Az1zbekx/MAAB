ism = input("Ismingiz: ")
yil = int(input("Tug‘ilgan yilingiz: "))
print(f"{ism}, sizning yoshingiz {2025 - yil} da.")
