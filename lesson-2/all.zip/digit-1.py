son = float(input("Sonni kiriting: "))
print("Yaxlitlangan:", round(son, 2))
