km = float(input("Kilometr: "))
metr = km * 1000
sm = km * 100000
print("Metr:", metr)
print("Santimetr:", sm)
