a = int(input("1-son: "))
b = int(input("2-son: "))
print("Bo‘linma:", a // b)
print("Qoldiq:", a % b)
