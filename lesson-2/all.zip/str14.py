a = input("1-satr: ")
b = input("2-satr: ")
print("Teng" if a == b else "Teng emas")
