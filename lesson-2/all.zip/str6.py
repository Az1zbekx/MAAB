a = input("Matn: ")
b = input("Qidiriladigan so‘z: ")
print("Bor" if b in a else "Yo‘q")
