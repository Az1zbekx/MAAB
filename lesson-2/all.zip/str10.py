gap = input("Gap: ")
print("So‘zlar soni:", len(gap.split()))
