son = int(input("Son: "))
if son % 2 == 0:
    print("Juft")
else:
    print("Toq")
