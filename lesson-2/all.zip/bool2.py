a = float(input("1-son: "))
b = float(input("2-son: "))

if a == b:
    print("Ikkala raqam teng.")
else:
    print("Raqamlar teng emas.")
