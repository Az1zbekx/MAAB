a = float(input("1-son: "))
b = float(input("2-son: "))
c = float(input("3-son: "))

print("Eng katta:", max(a, b, c))
print("Eng kichik:", min(a, b, c))
