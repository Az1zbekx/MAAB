satr = input("Satr: ")
print("Teskari:", satr[::-1])
