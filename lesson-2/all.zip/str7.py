gap = input("Gap: ")
qidir = input("Nimani almashtiraylik? ")
yangi = input("Nima bilan? ")
print(gap.replace(qidir, yangi))
