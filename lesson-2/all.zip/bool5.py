s1 = input("1-qator: ")
s2 = input("2-qator: ")

if len(s1) == len(s2):
    print("Ikkala qator uzunligi bir xil.")
else:
    print("Qatorlar uzunligi turlicha.")
