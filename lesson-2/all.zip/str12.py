sozlar = input("So‘zlar (bo‘sh joy bilan): ").split()
print(",".join(sozlar))
