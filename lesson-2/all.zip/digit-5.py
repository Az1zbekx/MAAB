c = float(input("Selsiy: "))
f = (c * 9/5) + 32
print("Farengeyt:", f)
