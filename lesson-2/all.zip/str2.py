txt = "LMaasleitbtui"
print(txt[::2])
print(txt[1::2])
