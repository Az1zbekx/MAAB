a = int(input("1-son: "))
b = int(input("2-son: "))
c = int(input("3-son: "))

if a != b and b != c and a != c:
    print("Barcha sonlar har xil.")
else:
    print("Kamida ikkita son bir xil.")
