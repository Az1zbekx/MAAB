son = int(input("Son: "))
print("Oxirgi raqam:", abs(son) % 10)
