foydalanuvchi = input("Foydalanuvchi nomi: ")
parol = input("Parol: ")

if foydalanuvchi and parol:
    print("Kirish muvaffaqiyatli.")
else:
    print("Foydalanuvchi nomi va parol bo‘sh bo‘lmasligi kerak.")
