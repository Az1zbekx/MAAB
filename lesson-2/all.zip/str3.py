satr = input("Satr kiriting: ")
print("Uzunligi:", len(satr))
print("Katta harflar:", satr.upper())
print("Kichik harflar:", satr.lower())
