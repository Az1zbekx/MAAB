son = int(input("Son: "))

if son % 3 == 0 and son % 5 == 0:
    print("Son 3 ga ham, 5 ga ham bo‘linadi.")
else:
    print("Bo‘linmaydi.")
