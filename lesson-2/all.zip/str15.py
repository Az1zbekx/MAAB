gap = input("Gap: ")
print("Qisqartma:", ''.join(i[0].upper() for i in gap.split()))
