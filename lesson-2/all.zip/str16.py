satr = input("Satr: ")
belgi = input("Qaysi belgini o‘chiraylik? ")
print(satr.replace(belgi, ""))
