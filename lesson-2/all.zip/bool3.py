son = int(input("Son kiriting: "))

if son > 0 and son % 2 == 0:
    print("Son musbat va juft.")
else:
    print("Shart bajarilmadi.")
