satr = input("Satr: ")
print("Raqam bor" if any(c.isdigit() for c in satr) else "Raqam yo‘q")
