satr = input("Satr: ").replace(" ", "").lower()
if satr == satr[::-1]:
    print("Palindrom")
else:
    print("Palindrom emas")
