import os

def load_data():
    data = []
    if not os.path.exists("employees.txt"):
        return data
    with open("employees.txt", "r") as file:
        for line in file:
            parts = line.strip().split(", ")
            if len(parts) == 4:
                try:
                    data.append({
                        "id": int(parts[0]),
                        "name": parts[1],
                        "position": parts[2],
                        "salary": int(parts[3])
                    })
                except ValueError:
                    continue
    return data

def save_data(data):
    with open("employees.txt", "w") as file:
        for emp in data:
            file.write(f"{emp['id']}, {emp['name']}, {emp['position']}, {emp['salary']}\n")

def add_employee():
    data = load_data()
    ids = {emp["id"] for emp in data}
    while True:
        try:
            ID = int(input("ID = "))
            if ID <= 0:
                print("ID must be positive.")
                continue
            if ID in ids:
                print("This ID exists, enter another one.")
                continue
            break
        except ValueError:
            print("ID must be an integer.")

    name = input("Name = ")
    position = input("Position = ")

    while True:
        try:
            salary = int(input("Salary = "))
            if salary <= 0:
                print("Salary must be positive.")
                continue
            break
        except ValueError:
            print("Salary must be an integer.")

    data.append({"id": ID, "name": name, "position": position, "salary": salary})
    save_data(data)
    print("Employee added successfully.")

def view_employees():
    data = load_data()
    if not data:
        print("No employee records found.")
        return
    for emp in data:
        print(f"{emp['id']}, {emp['name']}, {emp['position']}, {emp['salary']}")

def search_employee():
    data = load_data()
    try:
        ID = int(input("ID = "))
        if ID <= 0:
            print("ID must be positive.")
            return
    except ValueError:
        print("ID must be an integer.")
        return
    for emp in data:
        if emp["id"] == ID:
            print(f"{emp['id']}, {emp['name']}, {emp['position']}, {emp['salary']}")
            return
    print("Employee not found.")

def update_employee():
    data = load_data()
    try:
        ID = int(input("ID = "))
        if ID <= 0:
            print("ID must be positive.")
            return
    except ValueError:
        print("ID must be an integer.")
        return
    for emp in data:
        if emp["id"] == ID:
            emp["name"] = input("New name = ")
            emp["position"] = input("New position = ")
            while True:
                try:
                    salary = int(input("New salary = "))
                    if salary <= 0:
                        print("Salary must be positive.")
                        continue
                    emp["salary"] = salary
                    break
                except ValueError:
                    print("Salary must be an integer.")
            save_data(data)
            print("Employee updated successfully.")
            return
    print("Employee not found.")

def delete_employee():
    data = load_data()
    try:
        ID = int(input("ID = "))
        if ID <= 0:
            print("ID must be positive.")
            return
    except ValueError:
        print("ID must be an integer.")
        return
    new_data = [emp for emp in data if emp["id"] != ID]
    if len(new_data) == len(data):
        print("Employee not found.")
    else:
        save_data(new_data)
        print("Employee deleted successfully.")

def main():
    while True:
        print("\n1. Add\n2. View\n3. Search\n4. Update\n5. Delete\n6. Exit")
        try:
            command = int(input("Enter command: "))
            match command:
                case 1:
                    add_employee()
                case 2:
                    view_employees()
                case 3:
                    search_employee()
                case 4:
                    update_employee()
                case 5:
                    delete_employee()
                case 6:
                    print("Thank you! Exiting.")
                    break
                case _:
                    print("Please enter a number between 1 and 6.")
        except ValueError:
            print("Command must be a number.")

if __name__ == "__main__":
    main()
