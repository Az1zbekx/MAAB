name = input("Salom MAAB ga xush kelibsiz\nIsmingiz nima: ")
age = int(input("Yoshingiz nechida: "))
if age >= 18:
    print(f"{name} sizning yoshingiz {age} bo'lgani uchun bizda ta'lim olishingiz mumkin")
else:
    print(f"{name} sizning yoshingiz 18 da kichik bo'lgani sababli bizda ta'lim olishingiz mumkin emas")
